This is a reference implementation of a Suppliers-Parts-Jobs (SPJ) database.
It is similar, but not identical, to the SPJ database used in Calvin College
CS 262 [class 8](https://cs.calvin.edu/courses/cs/262/kvlinden/08is/class.html).
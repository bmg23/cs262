This sample Monopoly database and set of queries is used in Calvin College
CS 262 [lab 7](https://cs.calvin.edu/courses/cs/262/kvlinden/07is/lab.html).